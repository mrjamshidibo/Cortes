# AutoDock Automation Architecture

This document describes the architecture of the AutoDock Automation package, which is designed to automate molecular docking workflows using AutoDock Vina.

## System Overview

The AutoDock Automation package is organized into several modules, each responsible for a specific part of the docking workflow:

```
autodock_automation/
├── cli.py                # Command-line interface
├── config.py             # Configuration and settings
├── downloader/           # PDB structure downloading
├── parser/               # PDB processing and analysis
├── active_site/          # Active site detection
├── prepare/              # Receptor preparation
├── ligand/               # Ligand processing
├── docking/              # AutoDock Vina execution
├── analysis/             # Result parsing and visualization
└── utils/                # Common utilities
```

## Module Responsibilities

### CLI Module (`cli.py`)

The CLI module provides a command-line interface for the package, allowing users to specify docking parameters and configure the workflow.

Key features:
- Command-line arguments for different docking modes
- Parameter validation
- Workflow orchestration

### Configuration Module (`config.py`)

The configuration module handles default settings, logging setup, and parameter validation.

Key features:
- Default docking parameters
- Logging configuration
- Parameter validation

### Downloader Module (`downloader/pdb_fetcher.py`)

The downloader module is responsible for retrieving protein structures from the Protein Data Bank (PDB).

Key features:
- Download PDB files by PDB ID
- Download PDB files by UniProt ID
- Validate downloaded structures

### Parser Module (`parser/hetero_parser.py`)

The parser module processes PDB files to identify heteroatoms and ligands.

Key features:
- Identify heteroatoms in PDB files
- Filter for drug-like molecules
- Extract ligands from PDB files

### Active Site Module (`active_site/pocket_detector.py`)

The active site module detects binding pockets in protein structures.

Key features:
- Detect binding pockets based on ligand coordinates
- Detect binding pockets based on protein structure
- Identify residues in binding pockets

### Receptor Preparation Module (`prepare/receptor_prep.py`)

The receptor preparation module prepares protein structures for docking.

Key features:
- Remove water molecules
- Remove heteroatoms
- Add polar hydrogen atoms
- Fix missing atoms
- Assign charges
- Convert to PDBQT format

### Ligand Module (`ligand/ligand_builder.py`)

The ligand module builds and prepares ligand structures for docking.

Key features:
- Convert SMILES to 3D structures
- Optimize ligand structures
- Identify rotatable bonds
- Convert to PDBQT format

### Docking Module (`docking/vina_runner.py`)

The docking module runs AutoDock Vina docking simulations.

Key features:
- Generate Vina configuration files
- Run docking simulations
- Check Vina installation

### Analysis Module (`analysis/`)

The analysis module parses and visualizes docking results.

Key components:
- `result_parser.py`: Parse docking results
- `visualization.py`: Visualize docking results

Key features:
- Parse PDBQT output files
- Extract binding energies and poses
- Generate plots and reports
- Create 3D visualizations

### Utilities Module (`utils/file_manager.py`)

The utilities module provides common helper functions.

Key features:
- File and directory management
- Temporary file handling

## Workflow

The typical workflow consists of the following steps:

1. **Input Processing**: Parse command-line arguments and validate parameters.
2. **Structure Preparation**:
   - Download receptor structures (if necessary)
   - Identify ligands in PDB files (if necessary)
   - Prepare receptor structures
   - Prepare ligand structures
3. **Docking Setup**:
   - Detect active sites
   - Generate Vina configuration files
4. **Docking Execution**:
   - Run AutoDock Vina
5. **Results Analysis**:
   - Parse docking results
   - Generate reports and visualizations

## Design Principles

The package is designed with the following principles in mind:

- **Modularity**: Each component has a specific responsibility.
- **Extensibility**: New features can be added without modifying existing functionality.
- **Robustness**: Comprehensive error handling and logging.
- **User-Friendliness**: Simple command-line interface with sensible defaults.