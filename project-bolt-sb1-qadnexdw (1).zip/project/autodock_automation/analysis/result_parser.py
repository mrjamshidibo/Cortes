"""
Module for parsing and analyzing AutoDock Vina docking results.
"""

from typing import List, Dict, Any, Tuple, Optional
import os
import re
import pandas as pd
from loguru import logger


class ResultParser:
    """Class for parsing and analyzing AutoDock Vina docking results."""
    
    def __init__(self):
        """Initialize the result parser."""
        logger.debug("ResultParser initialized")
    
    def parse(self, results_path: str) -> pd.DataFrame:
        """
        Parse AutoDock Vina docking results.
        
        Args:
            results_path: Path to the docking results file (PDBQT).
            
        Returns:
            DataFrame with docking results.
        """
        logger.info(f"Parsing docking results: {results_path}")
        
        try:
            # Parse the PDBQT file to extract binding modes
            binding_modes = self._parse_pdbqt(results_path)
            
            # Create a DataFrame
            df = pd.DataFrame(binding_modes)
            
            logger.info(f"Parsed {len(df)} binding modes")
            return df
            
        except Exception as e:
            logger.error(f"Error parsing docking results: {str(e)}")
            return pd.DataFrame()
    
    def _parse_pdbqt(self, pdbqt_file: str) -> List[Dict[str, Any]]:
        """
        Parse a PDBQT file to extract binding modes.
        
        Args:
            pdbqt_file: Path to the PDBQT file.
            
        Returns:
            List of dictionaries with binding mode information.
        """
        binding_modes = []
        
        try:
            with open(pdbqt_file, "r") as f:
                content = f.read()
            
            # Split the file by MODEL records
            models = re.split(r"MODEL\s+\d+", content)
            
            # Skip the first element (empty or header)
            models = models[1:] if models else []
            
            for i, model in enumerate(models):
                # Extract binding energy
                energy_match = re.search(r"REMARK VINA RESULT:\s+([-\d.]+)", model)
                if energy_match:
                    binding_energy = float(energy_match.group(1))
                else:
                    binding_energy = None
                
                # Extract RMSD values
                rmsd_match = re.search(r"REMARK VINA RESULT:.*\s+([\d.]+)\s+([\d.]+)", model)
                if rmsd_match:
                    rmsd_lb = float(rmsd_match.group(1))
                    rmsd_ub = float(rmsd_match.group(2))
                else:
                    rmsd_lb = None
                    rmsd_ub = None
                
                # Add the binding mode to the list
                binding_modes.append({
                    "mode": i + 1,
                    "binding_energy": binding_energy,
                    "rmsd_lb": rmsd_lb,
                    "rmsd_ub": rmsd_ub,
                    "model_text": model.strip(),
                })
            
            logger.debug(f"Extracted {len(binding_modes)} binding modes from {pdbqt_file}")
            return binding_modes
            
        except Exception as e:
            logger.error(f"Error parsing PDBQT file {pdbqt_file}: {str(e)}")
            return []
    
    def parse_log(self, log_file: str) -> pd.DataFrame:
        """
        Parse AutoDock Vina log file.
        
        Args:
            log_file: Path to the log file.
            
        Returns:
            DataFrame with docking information.
        """
        logger.info(f"Parsing log file: {log_file}")
        
        try:
            # Read the log file
            with open(log_file, "r") as f:
                content = f.read()
            
            # Extract docking information
            info = {}
            
            # Extract center coordinates
            center_match = re.search(r"Center: X=([\d.-]+) Y=([\d.-]+) Z=([\d.-]+)", content)
            if center_match:
                info["center_x"] = float(center_match.group(1))
                info["center_y"] = float(center_match.group(2))
                info["center_z"] = float(center_match.group(3))
            
            # Extract box size
            size_match = re.search(r"Size: X=([\d.]+) Y=([\d.]+) Z=([\d.]+)", content)
            if size_match:
                info["size_x"] = float(size_match.group(1))
                info["size_y"] = float(size_match.group(2))
                info["size_z"] = float(size_match.group(3))
            
            # Extract docking parameters
            exhaustiveness_match = re.search(r"Exhaustiveness: (\d+)", content)
            if exhaustiveness_match:
                info["exhaustiveness"] = int(exhaustiveness_match.group(1))
            
            seed_match = re.search(r"Seed: (\d+)", content)
            if seed_match:
                info["seed"] = int(seed_match.group(1))
            
            # Extract timing information
            time_match = re.search(r"Refining results.*?\s+([\d.]+)s", content)
            if time_match:
                info["time"] = float(time_match.group(1))
            
            # Extract binding modes
            mode_pattern = r"^\s*(\d+)\s+([-\d.]+)\s+([\d.]+)\s+([\d.]+)"
            mode_matches = re.findall(mode_pattern, content, re.MULTILINE)
            
            modes = []
            for mode, energy, rmsd_lb, rmsd_ub in mode_matches:
                modes.append({
                    "mode": int(mode),
                    "binding_energy": float(energy),
                    "rmsd_lb": float(rmsd_lb),
                    "rmsd_ub": float(rmsd_ub),
                })
            
            # Create DataFrame for modes
            modes_df = pd.DataFrame(modes)
            
            # Add docking information as columns
            for key, value in info.items():
                modes_df[key] = value
            
            logger.info(f"Parsed log file with {len(modes_df)} binding modes")
            return modes_df
            
        except Exception as e:
            logger.error(f"Error parsing log file {log_file}: {str(e)}")
            return pd.DataFrame()
    
    def extract_best_poses(self, results_path: str, num_poses: int = 3) -> List[str]:
        """
        Extract the best binding poses from docking results.
        
        Args:
            results_path: Path to the docking results file (PDBQT).
            num_poses: Number of best poses to extract.
            
        Returns:
            List of paths to extracted pose files.
        """
        logger.info(f"Extracting best {num_poses} poses from {results_path}")
        
        try:
            # Parse the PDBQT file
            binding_modes = self._parse_pdbqt(results_path)
            
            if not binding_modes:
                logger.warning(f"No binding modes found in {results_path}")
                return []
            
            # Sort binding modes by binding energy
            binding_modes.sort(key=lambda x: x["binding_energy"] if x["binding_energy"] is not None else float("inf"))
            
            # Limit to the requested number of poses
            binding_modes = binding_modes[:num_poses]
            
            # Extract each pose to a separate file
            pose_files = []
            output_dir = os.path.dirname(results_path)
            
            for i, mode in enumerate(binding_modes):
                # Create a PDBQT file for this pose
                pose_file = os.path.join(output_dir, f"pose_{i+1}.pdbqt")
                
                with open(pose_file, "w") as f:
                    f.write(f"MODEL {i+1}\n")
                    f.write(f"REMARK VINA RESULT: {mode['binding_energy']} {mode['rmsd_lb']} {mode['rmsd_ub']}\n")
                    f.write(mode["model_text"])
                    f.write("\nENDMDL\n")
                
                pose_files.append(pose_file)
                logger.debug(f"Extracted pose {i+1} to {pose_file}")
            
            logger.info(f"Extracted {len(pose_files)} best poses")
            return pose_files
            
        except Exception as e:
            logger.error(f"Error extracting best poses: {str(e)}")
            return []