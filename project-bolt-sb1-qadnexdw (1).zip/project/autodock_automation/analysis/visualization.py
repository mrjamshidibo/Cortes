"""
Module for visualizing and analyzing AutoDock Vina docking results.
"""

from typing import List, Dict, Any, Optional
import os
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from loguru import logger


class Visualization:
    """Class for visualizing and analyzing AutoDock Vina docking results."""
    
    def __init__(self):
        """Initialize the visualization class."""
        logger.debug("Visualization initialized")
    
    def plot_binding_energies(self, df: pd.DataFrame, output_path: str) -> None:
        """
        Plot binding energies of docking results.
        
        Args:
            df: DataFrame with docking results.
            output_path: Path to save the plot.
        """
        logger.info(f"Plotting binding energies to: {output_path}")
        
        try:
            # Create the plot
            plt.figure(figsize=(10, 6))
            
            # Check if the DataFrame is not empty and has the required columns
            if not df.empty and "binding_energy" in df.columns and "mode" in df.columns:
                # Sort by mode number
                df_sorted = df.sort_values("mode")
                
                # Plot binding energies
                plt.bar(df_sorted["mode"], df_sorted["binding_energy"], color="skyblue")
                plt.axhline(y=df_sorted["binding_energy"].min(), color="red", linestyle="--", 
                           label=f"Best: {df_sorted['binding_energy'].min():.2f} kcal/mol")
                
                # Add labels and title
                plt.xlabel("Binding Mode")
                plt.ylabel("Binding Energy (kcal/mol)")
                plt.title("Binding Energies of Docking Poses")
                
                # Add grid
                plt.grid(True, linestyle="--", alpha=0.7)
                
                # Add legend
                plt.legend()
                
            else:
                # Create a message if no data is available
                plt.text(0.5, 0.5, "No docking data available", 
                        horizontalalignment="center", verticalalignment="center",
                        transform=plt.gca().transAxes, fontsize=14)
                plt.title("Binding Energies Plot")
            
            # Create the output directory if it doesn't exist
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # Save the plot
            plt.tight_layout()
            plt.savefig(output_path, dpi=300)
            plt.close()
            
            logger.info(f"Binding energies plot saved to: {output_path}")
            
        except Exception as e:
            logger.error(f"Error plotting binding energies: {str(e)}")
    
    def generate_3d_images(self, pose_files: List[str], output_dir: str) -> None:
        """
        Generate 3D images of docking poses.
        
        Args:
            pose_files: List of paths to pose files.
            output_dir: Directory to save the images.
        """
        logger.info(f"Generating 3D images in: {output_dir}")
        
        try:
            # Create the output directory if it doesn't exist
            os.makedirs(output_dir, exist_ok=True)
            
            # Use py3Dmol to generate images
            try:
                import py3Dmol
                
                for i, pose_file in enumerate(pose_files):
                    if not os.path.isfile(pose_file):
                        logger.warning(f"Pose file not found: {pose_file}")
                        continue
                    
                    # Create a py3Dmol view
                    view = py3Dmol.view(width=800, height=600)
                    
                    # Load the pose
                    with open(pose_file, "r") as f:
                        view.addModel(f.read(), "pdbqt")
                    
                    # Set up the view
                    view.setStyle({"stick": {}})
                    view.zoomTo()
                    
                    # Save the image
                    output_path = os.path.join(output_dir, f"pose_{i+1}.png")
                    view.png()
                    
                    logger.debug(f"Generated 3D image for pose {i+1}: {output_path}")
                
                logger.info(f"Generated 3D images for {len(pose_files)} poses")
                
            except ImportError:
                logger.warning("py3Dmol not available, skipping 3D image generation")
                logger.warning("Install py3Dmol with: pip install py3Dmol")
            
        except Exception as e:
            logger.error(f"Error generating 3D images: {str(e)}")
    
    def save_to_excel(self, df: pd.DataFrame, output_file: str) -> None:
        """
        Save docking results to an Excel file.
        
        Args:
            df: DataFrame with docking results.
            output_file: Path to save the Excel file.
        """
        logger.info(f"Saving docking results to Excel: {output_file}")
        
        try:
            # Create the output directory if it doesn't exist
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # Check if the DataFrame is empty
            if df.empty:
                logger.warning("DataFrame is empty, creating an empty Excel file")
                
                # Create an empty DataFrame with column headers
                df = pd.DataFrame(columns=[
                    "mode", "binding_energy", "rmsd_lb", "rmsd_ub", 
                    "center_x", "center_y", "center_z", 
                    "size_x", "size_y", "size_z",
                ])
            
            # Save to Excel
            df.to_excel(output_file, sheet_name="Docking Results", index=False)
            
            logger.info(f"Docking results saved to: {output_file}")
            
        except Exception as e:
            logger.error(f"Error saving to Excel: {str(e)}")
    
    def create_report(self, df: pd.DataFrame, output_dir: str, 
                     receptor_path: str, ligand_path: str) -> None:
        """
        Create a comprehensive HTML report of docking results.
        
        Args:
            df: DataFrame with docking results.
            output_dir: Directory to save the report.
            receptor_path: Path to the receptor file.
            ligand_path: Path to the ligand file.
        """
        logger.info(f"Creating docking report in: {output_dir}")
        
        try:
            # Create the output directory if it doesn't exist
            os.makedirs(output_dir, exist_ok=True)
            
            # Create a report HTML file
            report_path = os.path.join(output_dir, "docking_report.html")
            
            # Generate plots for the report
            plot_path = os.path.join(output_dir, "binding_energies.png")
            self.plot_binding_energies(df, plot_path)
            
            # Create an HTML report
            with open(report_path, "w") as f:
                f.write("<html>\n<head>\n")
                f.write("<title>AutoDock Vina Docking Report</title>\n")
                f.write("<style>\n")
                f.write("body { font-family: Arial, sans-serif; margin: 20px; }\n")
                f.write("h1, h2 { color: #2c3e50; }\n")
                f.write("table { border-collapse: collapse; width: 100%; }\n")
                f.write("th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }\n")
                f.write("th { background-color: #f2f2f2; }\n")
                f.write("tr:nth-child(even) { background-color: #f9f9f9; }\n")
                f.write("img { max-width: 800px; border: 1px solid #ddd; }\n")
                f.write("</style>\n</head>\n<body>\n")
                
                # Header
                f.write("<h1>AutoDock Vina Docking Report</h1>\n")
                
                # Input files
                f.write("<h2>Input Files</h2>\n")
                f.write("<p><strong>Receptor:</strong> ")
                f.write(os.path.basename(receptor_path))
                f.write("</p>\n")
                f.write("<p><strong>Ligand:</strong> ")
                f.write(os.path.basename(ligand_path))
                f.write("</p>\n")
                
                # Docking results
                f.write("<h2>Docking Results</h2>\n")
                
                if not df.empty:
                    # Convert DataFrame to HTML table
                    f.write(df.to_html(index=False))
                else:
                    f.write("<p>No docking results available.</p>\n")
                
                # Binding energies plot
                f.write("<h2>Binding Energies</h2>\n")
                if os.path.isfile(plot_path):
                    rel_path = os.path.relpath(plot_path, output_dir)
                    f.write(f"<img src='{rel_path}' alt='Binding Energies Plot'>\n")
                else:
                    f.write("<p>No binding energies plot available.</p>\n")
                
                # 3D poses
                f.write("<h2>3D Poses</h2>\n")
                poses_dir = os.path.join(output_dir, "3d_visuals")
                if os.path.isdir(poses_dir):
                    pose_images = [f for f in os.listdir(poses_dir) if f.endswith(".png")]
                    if pose_images:
                        for pose_img in sorted(pose_images):
                            pose_path = os.path.join(poses_dir, pose_img)
                            rel_path = os.path.relpath(pose_path, output_dir)
                            f.write(f"<h3>{pose_img}</h3>\n")
                            f.write(f"<img src='{rel_path}' alt='{pose_img}'>\n")
                    else:
                        f.write("<p>No 3D pose images available.</p>\n")
                else:
                    f.write("<p>No 3D pose images available.</p>\n")
                
                # Footer
                f.write("<hr>\n")
                f.write("<p><em>Generated by AutoDock Automation</em></p>\n")
                f.write("</body>\n</html>")
            
            logger.info(f"Docking report created: {report_path}")
            
        except Exception as e:
            logger.error(f"Error creating docking report: {str(e)}")