"""
Module for parsing and identifying heteroatoms in PDB files.
"""

from typing import List, Dict, Any, Tuple
import os
from loguru import logger

from Bio.PDB import PDBParser, Select
from Bio.PDB.PDBIO import PDBIO


class Atom:
    """Class representing an atom in a PDB file."""
    
    def __init__(self, atom_id: int, name: str, element: str, residue_name: str, 
                 residue_id: Tuple[str, int, str], chain_id: str, coords: Tuple[float, float, float]):
        """
        Initialize an Atom object.
        
        Args:
            atom_id: Atom ID in the PDB file.
            name: Atom name.
            element: Element symbol.
            residue_name: Residue name.
            residue_id: Residue ID in the format (hetflag, resseq, icode).
            chain_id: Chain ID.
            coords: 3D coordinates (x, y, z).
        """
        self.atom_id = atom_id
        self.name = name
        self.element = element
        self.residue_name = residue_name
        self.residue_id = residue_id
        self.chain_id = chain_id
        self.coords = coords
    
    def __str__(self) -> str:
        """String representation of the atom."""
        return f"Atom({self.atom_id}, {self.name}, {self.element}, {self.residue_name}, {self.residue_id}, {self.chain_id})"
    
    def __repr__(self) -> str:
        """Representation of the atom."""
        return self.__str__()


class HeteroAtomParser:
    """Class for parsing and identifying heteroatoms in PDB files."""
    
    def __init__(self):
        """Initialize the heteroatom parser."""
        self.parser = PDBParser(QUIET=True)
        logger.debug("HeteroAtomParser initialized")
    
    def identify_heteroatoms(self, pdb_file: str) -> List[Atom]:
        """
        Identify heteroatoms in a PDB file.
        
        Args:
            pdb_file: Path to the PDB file.
            
        Returns:
            List of Atom objects representing heteroatoms.
        """
        logger.info(f"Identifying heteroatoms in: {pdb_file}")
        
        try:
            # Parse the PDB file
            structure = self.parser.get_structure("temp", pdb_file)
            
            # Extract heteroatoms
            heteroatoms = []
            for model in structure:
                for chain in model:
                    for residue in chain:
                        # Check if the residue is a heteroatom (HETATM)
                        if residue.id[0] != " ":
                            # Extract atoms from this residue
                            for atom in residue:
                                heteroatoms.append(Atom(
                                    atom_id=atom.serial_number,
                                    name=atom.name,
                                    element=atom.element,
                                    residue_name=residue.resname,
                                    residue_id=residue.id,
                                    chain_id=chain.id,
                                    coords=atom.coord,
                                ))
            
            logger.info(f"Found {len(heteroatoms)} heteroatoms in {pdb_file}")
            return heteroatoms
            
        except Exception as e:
            logger.error(f"Error parsing PDB file {pdb_file}: {str(e)}")
            return []
    
    def filter_drug_like(self, heteroatoms: List[Atom]) -> List[Atom]:
        """
        Filter heteroatoms to keep only drug-like molecules.
        
        Args:
            heteroatoms: List of Atom objects.
            
        Returns:
            Filtered list of Atom objects.
        """
        logger.info(f"Filtering {len(heteroatoms)} heteroatoms for drug-like molecules")
        
        # Exclude common non-drug-like molecules
        excluded_residues = {
            "HOH", "WAT", "H2O",  # Water
            "SO4", "PO4",          # Sulfate, phosphate
            "CL", "NA", "MG", "CA", "ZN", "MN", "FE",  # Common ions
        }
        
        # Group atoms by residue
        residues = {}
        for atom in heteroatoms:
            res_key = (atom.chain_id, atom.residue_id)
            if res_key not in residues:
                residues[res_key] = []
            residues[res_key].append(atom)
        
        # Filter residues
        filtered_atoms = []
        for res_key, atoms in residues.items():
            # Skip excluded residues
            if atoms[0].residue_name in excluded_residues:
                continue
            
            # Check if the residue has a minimum number of atoms (to exclude small molecules)
            if len(atoms) < 5:
                continue
            
            # Add atoms from this residue to the filtered list
            filtered_atoms.extend(atoms)
        
        logger.info(f"Filtered {len(heteroatoms)} heteroatoms to {len(filtered_atoms)} drug-like atoms")
        return filtered_atoms
    
    def extract_ligands(self, pdb_file: str, output_dir: str) -> List[str]:
        """
        Extract ligands from a PDB file and save them as separate PDB files.
        
        Args:
            pdb_file: Path to the PDB file.
            output_dir: Directory to save extracted ligands.
            
        Returns:
            List of paths to extracted ligand files.
        """
        logger.info(f"Extracting ligands from: {pdb_file}")
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Identify and filter heteroatoms
        heteroatoms = self.identify_heteroatoms(pdb_file)
        drug_like_atoms = self.filter_drug_like(heteroatoms)
        
        if not drug_like_atoms:
            logger.warning(f"No drug-like molecules found in {pdb_file}")
            return []
        
        # Group atoms by residue
        residues = {}
        for atom in drug_like_atoms:
            res_key = (atom.chain_id, atom.residue_id)
            if res_key not in residues:
                residues[res_key] = []
            residues[res_key].append(atom)
        
        # Create a custom selection class for extracting each ligand
        class LigandSelect(Select):
            def __init__(self, chain_id, residue_id):
                self.chain_id = chain_id
                self.residue_id = residue_id
            
            def accept_residue(self, residue):
                if residue.get_parent().id == self.chain_id and residue.id == self.residue_id:
                    return True
                return False
        
        # Extract each ligand
        ligand_files = []
        structure = self.parser.get_structure("temp", pdb_file)
        io = PDBIO()
        io.set_structure(structure)
        
        for i, (res_key, atoms) in enumerate(residues.items()):
            chain_id, residue_id = res_key
            output_file = os.path.join(output_dir, f"ligand_{i+1}_{atoms[0].residue_name}.pdb")
            
            try:
                io.save(output_file, LigandSelect(chain_id, residue_id))
                ligand_files.append(output_file)
                logger.debug(f"Extracted ligand to: {output_file}")
            except Exception as e:
                logger.error(f"Error extracting ligand: {str(e)}")
        
        logger.info(f"Extracted {len(ligand_files)} ligands from {pdb_file}")
        return ligand_files