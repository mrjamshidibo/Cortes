"""
Module for downloading protein structures from the Protein Data Bank (PDB).
"""

import os
import tempfile
from typing import List, Optional
from pathlib import Path
import urllib.request
import urllib.error
from loguru import logger

from Bio import PDB
from Bio.PDB import PDBList


class PDBDownloader:
    """Class for downloading protein structures from the PDB."""
    
    def __init__(self, cache_dir: Optional[str] = None):
        """
        Initialize the PDB downloader.
        
        Args:
            cache_dir: Directory to cache downloaded PDB files.
        """
        if cache_dir is None:
            # Use a default cache directory
            self.cache_dir = os.path.join(tempfile.gettempdir(), "autodock_cache", "pdb")
        else:
            self.cache_dir = cache_dir
        
        # Create cache directory if it doesn't exist
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # Initialize PDBList for downloading
        self.pdb_list = PDBList(pdb=self.cache_dir)
        logger.debug(f"PDBDownloader initialized with cache directory: {self.cache_dir}")
    
    def fetch_by_pdb_id(self, pdb_id: str) -> str:
        """
        Download a PDB file by its PDB ID.
        
        Args:
            pdb_id: The PDB ID of the protein structure.
            
        Returns:
            Path to the downloaded PDB file.
            
        Raises:
            FileNotFoundError: If the PDB file could not be downloaded.
        """
        logger.info(f"Downloading PDB file with ID: {pdb_id}")
        
        # Check if the file already exists in the cache
        pdb_file = self._check_cache(pdb_id)
        if pdb_file:
            logger.debug(f"Found cached PDB file: {pdb_file}")
            return pdb_file
        
        # Download the PDB file
        try:
            pdb_file = self.pdb_list.retrieve_pdb_file(
                pdb_id,
                file_format="pdb",
                overwrite=False,
            )
            
            # Validate the download
            if not os.path.isfile(pdb_file):
                raise FileNotFoundError(f"Failed to download PDB file for ID: {pdb_id}")
            
            logger.info(f"Successfully downloaded PDB file: {pdb_file}")
            return pdb_file
            
        except Exception as e:
            logger.error(f"Error downloading PDB file for ID {pdb_id}: {str(e)}")
            raise FileNotFoundError(f"Failed to download PDB file for ID: {pdb_id}")
    
    def fetch_by_uniprot(self, uniprot_id: str) -> List[str]:
        """
        Download PDB files related to a UniProt ID.
        
        Args:
            uniprot_id: The UniProt ID of the protein.
            
        Returns:
            List of paths to downloaded PDB files.
            
        Raises:
            FileNotFoundError: If no PDB files could be found or downloaded.
        """
        logger.info(f"Fetching PDB files for UniProt ID: {uniprot_id}")
        
        # Query the PDB for structures related to the UniProt ID
        pdb_ids = self._get_pdb_ids_for_uniprot(uniprot_id)
        
        if not pdb_ids:
            logger.error(f"No PDB structures found for UniProt ID: {uniprot_id}")
            raise FileNotFoundError(f"No PDB structures found for UniProt ID: {uniprot_id}")
        
        logger.info(f"Found {len(pdb_ids)} PDB structures for UniProt ID: {uniprot_id}")
        
        # Download each PDB file
        pdb_files = []
        for pdb_id in pdb_ids:
            try:
                pdb_file = self.fetch_by_pdb_id(pdb_id)
                pdb_files.append(pdb_file)
            except FileNotFoundError as e:
                logger.warning(f"Could not download PDB ID {pdb_id}: {str(e)}")
        
        if not pdb_files:
            logger.error(f"Could not download any PDB files for UniProt ID: {uniprot_id}")
            raise FileNotFoundError(f"Could not download any PDB files for UniProt ID: {uniprot_id}")
        
        # Validate the downloads
        self.validate_downloads(pdb_files)
        
        return pdb_files
    
    def validate_downloads(self, file_paths: List[str]) -> None:
        """
        Ensure that downloaded PDB files are valid and complete.
        
        Args:
            file_paths: List of paths to PDB files.
            
        Raises:
            ValueError: If any PDB file is invalid or incomplete.
        """
        logger.info(f"Validating {len(file_paths)} downloaded PDB files")
        
        parser = PDB.PDBParser(QUIET=True)
        
        for file_path in file_paths:
            try:
                # Try to parse the PDB file
                structure = parser.get_structure("temp", file_path)
                
                # Check if the structure contains atoms
                atom_count = sum(1 for _ in structure.get_atoms())
                if atom_count == 0:
                    logger.warning(f"PDB file contains no atoms: {file_path}")
                else:
                    logger.debug(f"Validated PDB file with {atom_count} atoms: {file_path}")
                    
            except Exception as e:
                logger.error(f"Error validating PDB file {file_path}: {str(e)}")
                raise ValueError(f"Invalid PDB file: {file_path}")
    
    def _check_cache(self, pdb_id: str) -> Optional[str]:
        """
        Check if a PDB file exists in the cache.
        
        Args:
            pdb_id: The PDB ID to check.
            
        Returns:
            Path to the cached PDB file, or None if not found.
        """
        # PDB files are stored with lowercase IDs
        pdb_id = pdb_id.lower()
        
        # Check different possible file locations and formats
        possible_paths = [
            os.path.join(self.cache_dir, f"{pdb_id}.pdb"),
            os.path.join(self.cache_dir, f"pdb{pdb_id}.ent"),
            os.path.join(self.cache_dir, "divided", pdb_id[1:3], f"pdb{pdb_id}.ent"),
        ]
        
        for path in possible_paths:
            if os.path.isfile(path):
                return path
        
        return None
    
    def _get_pdb_ids_for_uniprot(self, uniprot_id: str) -> List[str]:
        """
        Get PDB IDs corresponding to a UniProt ID.
        
        Args:
            uniprot_id: The UniProt ID to query.
            
        Returns:
            List of PDB IDs.
        """
        # Define the URL for the UniProt-PDB mapping service
        url = f"https://www.uniprot.org/uniprot/{uniprot_id}.xml"
        
        try:
            # Download the UniProt entry
            with urllib.request.urlopen(url) as response:
                xml_data = response.read().decode('utf-8')
            
            # Extract PDB IDs from the XML data
            pdb_ids = []
            import re
            
            # Look for PDB cross-references in the XML
            matches = re.findall(r'<dbReference type="PDB" id="([^"]+)"', xml_data)
            pdb_ids.extend(matches)
            
            logger.debug(f"Found {len(pdb_ids)} PDB IDs for UniProt ID {uniprot_id}")
            return pdb_ids
            
        except urllib.error.URLError as e:
            logger.error(f"Error fetching UniProt entry for {uniprot_id}: {str(e)}")
            return []