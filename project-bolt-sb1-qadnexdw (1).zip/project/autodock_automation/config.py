"""
Configuration module for the AutoDock Automation package.
"""

import os
import sys
from typing import Dict, Any
from loguru import logger

# Default docking parameters
DEFAULT_EXHAUSTIVENESS = 8
DEFAULT_NUM_MODES = 9
DEFAULT_ENERGY_RANGE = 3.0

# Default search box size
DEFAULT_BOX_SIZE = 20.0

# Logging configuration
DEFAULT_LOG_FORMAT = (
    "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
    "<level>{level: <8}</level> | "
    "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
    "<level>{message}</level>"
)


def setup_logging(verbose: bool = False) -> None:
    """
    Configure the logging system.
    
    Args:
        verbose: If True, set log level to DEBUG, otherwise INFO.
    """
    # Remove default logger
    logger.remove()
    
    # Add custom configuration
    log_level = "DEBUG" if verbose else "INFO"
    
    # Console logger
    logger.add(
        sys.stderr,
        format=DEFAULT_LOG_FORMAT,
        level=log_level,
        colorize=True,
    )
    
    # File logger
    os.makedirs("logs", exist_ok=True)
    logger.add(
        "logs/autodock_automation.log",
        format=DEFAULT_LOG_FORMAT,
        level="DEBUG",
        rotation="10 MB",
        retention="1 week",
    )
    
    logger.debug("Logging system initialized")


def validate_docking_parameters(params: Dict[str, Any]) -> None:
    """
    Validate docking parameters.
    
    Args:
        params: Dictionary containing docking parameters.
        
    Raises:
        ValueError: If any parameter is invalid.
    """
    # Validate exhaustiveness
    if params.get("exhaustiveness") is not None:
        if params["exhaustiveness"] < 1:
            raise ValueError("Exhaustiveness must be a positive integer.")
    
    # Validate num_modes
    if params.get("num_modes") is not None:
        if params["num_modes"] < 1:
            raise ValueError("Number of modes must be a positive integer.")
    
    # Validate energy_range
    if params.get("energy_range") is not None:
        if params["energy_range"] <= 0:
            raise ValueError("Energy range must be a positive value.")
    
    # Validate box parameters if provided
    if all(params.get(p) is not None for p in ["center_x", "center_y", "center_z"]):
        # Validate box size
        for axis in ["size_x", "size_y", "size_z"]:
            if params.get(axis) is not None and params[axis] <= 0:
                raise ValueError(f"Box size ({axis}) must be positive.")
    
    logger.debug("Docking parameters validated")


def get_config_template_path() -> str:
    """
    Get the path to the Vina configuration template.
    
    Returns:
        Path to the template file.
    """
    # Get the directory of the current file
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Path to the template file
    template_path = os.path.join(current_dir, "templates", "vina_config.tpl")
    
    # Check if the template file exists
    if not os.path.isfile(template_path):
        logger.error(f"Template file not found: {template_path}")
        raise FileNotFoundError(f"Template file not found: {template_path}")
    
    return template_path