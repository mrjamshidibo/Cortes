"""
AutoDock Automation: A comprehensive Python package for automating molecular docking workflows with AutoDock Vina.
"""

__version__ = "0.1.0"