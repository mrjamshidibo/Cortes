"""
Module for running AutoDock Vina docking simulations.
"""

from typing import Dict, Any, Optional
import os
import subprocess
import tempfile
from loguru import logger

from ..config import get_config_template_path


class VinaRunner:
    """Class for running AutoDock Vina docking simulations."""
    
    def __init__(self, vina_executable: str = "vina"):
        """
        Initialize the Vina runner.
        
        Args:
            vina_executable: Path to the AutoDock Vina executable.
        """
        self.vina_executable = vina_executable
        logger.debug(f"VinaRunner initialized with executable: {vina_executable}")
    
    def generate_config(self, pocket: Dict[str, float], config_path: str,
                       exhaustiveness: int = 8, num_modes: int = 9,
                       energy_range: float = 3.0) -> str:
        """
        Generate a configuration file for AutoDock Vina.
        
        Args:
            pocket: Dictionary with pocket parameters.
            config_path: Path to save the configuration file.
            exhaustiveness: Exhaustiveness of the global search.
            num_modes: Maximum number of binding modes to generate.
            energy_range: Maximum energy difference between the best and worst binding mode.
            
        Returns:
            Path to the configuration file.
        """
        logger.info(f"Generating Vina configuration file: {config_path}")
        
        try:
            # Get the template path
            template_path = get_config_template_path()
            
            # Read the template
            with open(template_path, "r") as f:
                template = f.read()
            
            # Create a temporary directory
            output_dir = os.path.dirname(config_path)
            os.makedirs(output_dir, exist_ok=True)
            
            # Default values for out and log
            out_path = os.path.join(output_dir, "docked_ligand.pdbqt")
            log_path = os.path.join(output_dir, "vina_log.txt")
            
            # Fill in the template
            config = template.format(
                receptor="{receptor}",
                ligand="{ligand}",
                center_x=pocket["center_x"],
                center_y=pocket["center_y"],
                center_z=pocket["center_z"],
                size_x=pocket["size_x"],
                size_y=pocket["size_y"],
                size_z=pocket["size_z"],
                exhaustiveness=exhaustiveness,
                num_modes=num_modes,
                energy_range=energy_range,
                out=out_path,
                log=log_path,
            )
            
            # Write the configuration file
            with open(config_path, "w") as f:
                f.write(config)
            
            logger.info(f"Vina configuration file generated: {config_path}")
            return config_path
            
        except Exception as e:
            logger.error(f"Error generating Vina configuration file: {str(e)}")
            raise
    
    def run_docking(self, receptor_pdbqt: str, ligand_pdbqt: str, config_path: str,
                   output_path: Optional[str] = None, log_path: Optional[str] = None) -> str:
        """
        Run AutoDock Vina docking simulation.
        
        Args:
            receptor_pdbqt: Path to the receptor PDBQT file.
            ligand_pdbqt: Path to the ligand PDBQT file.
            config_path: Path to the configuration file.
            output_path: Path to save the docking results. If None, use the path in the config file.
            log_path: Path to save the log file. If None, use the path in the config file.
            
        Returns:
            Path to the docking results file.
        """
        logger.info("Running AutoDock Vina docking simulation")
        
        try:
            # Read the configuration file
            with open(config_path, "r") as f:
                config = f.read()
            
            # Update the configuration with the receptor and ligand paths
            config = config.replace("{receptor}", receptor_pdbqt)
            config = config.replace("{ligand}", ligand_pdbqt)
            
            # Create a temporary configuration file
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
                f.write(config)
                tmp_config_path = f.name
            
            # Run AutoDock Vina
            cmd = [self.vina_executable, "--config", tmp_config_path]
            
            if output_path is not None:
                cmd.extend(["--out", output_path])
            
            if log_path is not None:
                cmd.extend(["--log", log_path])
            
            logger.debug(f"Running command: {' '.join(cmd)}")
            
            # Run the command
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            # Clean up temporary file
            os.remove(tmp_config_path)
            
            if result.returncode != 0:
                logger.error(f"AutoDock Vina error: {result.stderr}")
                raise RuntimeError("AutoDock Vina failed to run")
            
            # Parse the output to find the path to the docking results
            if output_path is not None:
                results_path = output_path
            else:
                # Extract the output path from the configuration
                for line in config.split("\n"):
                    if line.startswith("out = "):
                        results_path = line.split(" = ")[1].strip()
                        break
                else:
                    raise ValueError("Output path not found in configuration file")
            
            logger.info(f"Docking simulation completed, results saved to: {results_path}")
            return results_path
            
        except Exception as e:
            logger.error(f"Error running docking simulation: {str(e)}")
            raise
    
    def check_vina_installation(self) -> bool:
        """
        Check if AutoDock Vina is installed and accessible.
        
        Returns:
            True if AutoDock Vina is installed, False otherwise.
        """
        logger.info("Checking AutoDock Vina installation")
        
        try:
            # Run AutoDock Vina with --help to check if it's installed
            cmd = [self.vina_executable, "--help"]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error("AutoDock Vina not found or not working properly")
                return False
            
            logger.info("AutoDock Vina is installed and working properly")
            return True
            
        except Exception as e:
            logger.error(f"Error checking AutoDock Vina installation: {str(e)}")
            return False