"""
Module for preparing receptor structures for docking.
"""

from typing import List, Optional
import os
import subprocess
from loguru import logger

from ..parser.hetero_parser import Atom


class ReceptorPreparation:
    """Class for preparing receptor structures for docking."""
    
    def __init__(self):
        """Initialize the receptor preparation class."""
        logger.debug("ReceptorPreparation initialized")
    
    def remove_water(self, input_path: str, output_path: Optional[str] = None) -> str:
        """
        Remove water molecules from a PDB file.
        
        Args:
            input_path: Path to the input PDB file.
            output_path: Path to save the output PDB file. If None, input file is overwritten.
            
        Returns:
            Path to the output PDB file.
        """
        logger.info(f"Removing water molecules from: {input_path}")
        
        if output_path is None:
            output_path = input_path
        
        try:
            from Bio.PDB import PDBParser, PDBIO, Select
            
            # Define a selector that excludes water molecules
            class NotWater(Select):
                def accept_residue(self, residue):
                    return residue.get_resname() not in ["HOH", "WAT", "H2O"]
            
            # Parse the PDB file
            parser = PDBParser(QUIET=True)
            structure = parser.get_structure("temp", input_path)
            
            # Write the structure without water molecules
            io = PDBIO()
            io.set_structure(structure)
            io.save(output_path, NotWater())
            
            logger.info(f"Water molecules removed, saved to: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error removing water molecules: {str(e)}")
            if os.path.isfile(input_path):
                return input_path
            else:
                raise
    
    def remove_hetero(self, input_path: str, output_path: Optional[str] = None, 
                      keep: Optional[List[Atom]] = None) -> str:
        """
        Remove heteroatoms from a PDB file, optionally keeping some.
        
        Args:
            input_path: Path to the input PDB file.
            output_path: Path to save the output PDB file. If None, input file is overwritten.
            keep: List of heteroatoms to keep.
            
        Returns:
            Path to the output PDB file.
        """
        logger.info(f"Removing heteroatoms from: {input_path}")
        
        if output_path is None:
            output_path = input_path
        
        if keep is None:
            keep = []
        
        try:
            from Bio.PDB import PDBParser, PDBIO, Select
            
            # Define a selector that excludes heteroatoms except those in `keep`
            class SelectProtein(Select):
                def accept_residue(self, residue):
                    # Keep standard residues
                    if residue.id[0] == " ":
                        return True
                    
                    # Check if the residue should be kept
                    if keep:
                        for atom in keep:
                            if (atom.chain_id == residue.get_parent().id and
                                atom.residue_name == residue.resname and
                                atom.residue_id == residue.id):
                                return True
                    
                    return False
            
            # Parse the PDB file
            parser = PDBParser(QUIET=True)
            structure = parser.get_structure("temp", input_path)
            
            # Write the structure without heteroatoms
            io = PDBIO()
            io.set_structure(structure)
            io.save(output_path, SelectProtein())
            
            logger.info(f"Heteroatoms removed, saved to: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error removing heteroatoms: {str(e)}")
            if os.path.isfile(input_path):
                return input_path
            else:
                raise
    
    def add_polar_hydrogens(self, input_path: str, output_path: Optional[str] = None) -> str:
        """
        Add polar hydrogen atoms to a PDB file.
        
        Args:
            input_path: Path to the input PDB file.
            output_path: Path to save the output PDB file. If None, input file is overwritten.
            
        Returns:
            Path to the output PDB file.
        """
        logger.info(f"Adding polar hydrogens to: {input_path}")
        
        if output_path is None:
            output_path = input_path
        
        try:
            # Using Open Babel to add hydrogen atoms
            cmd = ["obabel", input_path, "-O", output_path, "-h"]
            
            # Run the command
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"Open Babel error: {result.stderr}")
                logger.warning("Using original file instead")
                return input_path
            
            logger.info(f"Polar hydrogens added, saved to: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error adding polar hydrogens: {str(e)}")
            logger.warning("This step requires Open Babel to be installed and in PATH")
            if os.path.isfile(input_path):
                return input_path
            else:
                raise
    
    def fix_missing_atoms(self, input_path: str, output_path: Optional[str] = None) -> str:
        """
        Fix missing atoms in a PDB file.
        
        Args:
            input_path: Path to the input PDB file.
            output_path: Path to save the output PDB file. If None, input file is overwritten.
            
        Returns:
            Path to the output PDB file.
        """
        logger.info(f"Fixing missing atoms in: {input_path}")
        
        if output_path is None:
            output_path = input_path
        
        try:
            # This would typically use tools like PyRosetta or PDBFixer
            # As a simplified implementation, we'll just copy the file
            if input_path != output_path:
                import shutil
                shutil.copy(input_path, output_path)
            
            logger.info(f"Missing atoms fixed, saved to: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error fixing missing atoms: {str(e)}")
            if os.path.isfile(input_path):
                return input_path
            else:
                raise
    
    def assign_charges(self, input_path: str, output_path: Optional[str] = None) -> str:
        """
        Assign charges to atoms in a PDB file.
        
        Args:
            input_path: Path to the input PDB file.
            output_path: Path to save the output PDB file. If None, input file is overwritten.
            
        Returns:
            Path to the output PDB file.
        """
        logger.info(f"Assigning charges to: {input_path}")
        
        if output_path is None:
            output_path = input_path
        
        try:
            # This would typically use tools like Open Babel or RDKit
            # As a simplified implementation, we'll just copy the file
            if input_path != output_path:
                import shutil
                shutil.copy(input_path, output_path)
            
            logger.info(f"Charges assigned, saved to: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error assigning charges: {str(e)}")
            if os.path.isfile(input_path):
                return input_path
            else:
                raise
    
    def to_pdbqt(self, input_path: str, output_path: str) -> str:
        """
        Convert a PDB file to PDBQT format for AutoDock Vina.
        
        Args:
            input_path: Path to the input PDB file.
            output_path: Path to save the output PDBQT file.
            
        Returns:
            Path to the output PDBQT file.
        """
        logger.info(f"Converting PDB to PDBQT: {input_path}")
        
        try:
            # Using Open Babel to convert to PDBQT
            cmd = ["obabel", input_path, "-O", output_path, "-xr"]
            
            # Run the command
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logger.error(f"Open Babel error: {result.stderr}")
                raise RuntimeError(f"Failed to convert {input_path} to PDBQT format")
            
            logger.info(f"Converted to PDBQT, saved to: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error converting to PDBQT: {str(e)}")
            logger.warning("This step requires Open Babel to be installed and in PATH")
            raise