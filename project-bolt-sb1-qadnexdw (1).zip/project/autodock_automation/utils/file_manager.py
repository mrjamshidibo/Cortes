"""
Utility module for file and directory management.
"""

import os
import shutil
from pathlib import Path
from typing import List, Optional
from loguru import logger


class DirectoryCleaner:
    """Class for managing directories and cleaning up files."""
    
    def clean_output_dir(self, path: str, keep_files: Optional[List[str]] = None) -> None:
        """
        Clean the output directory by removing old files and setting up necessary subdirectories.
        
        Args:
            path: Path to the output directory.
            keep_files: List of filenames to keep (if any).
        """
        logger.info(f"Cleaning output directory: {path}")
        
        # Create the output directory if it doesn't exist
        os.makedirs(path, exist_ok=True)
        
        # Initialize list of files to keep
        if keep_files is None:
            keep_files = []
        
        # Add .gitkeep to the list of files to keep
        keep_files.append(".gitkeep")
        
        # Remove all files except those in keep_files
        for item in os.listdir(path):
            item_path = os.path.join(path, item)
            
            # Skip if item is in keep_files
            if item in keep_files:
                continue
            
            # Remove the item (file or directory)
            try:
                if os.path.isfile(item_path):
                    os.remove(item_path)
                    logger.debug(f"Removed file: {item_path}")
                elif os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                    logger.debug(f"Removed directory: {item_path}")
            except Exception as e:
                logger.warning(f"Failed to remove {item_path}: {str(e)}")
        
        # Create necessary subdirectories
        self._create_subdirectories(path)
        
        logger.info("Output directory cleaned successfully")
    
    def _create_subdirectories(self, base_path: str) -> None:
        """
        Create necessary subdirectories in the output directory.
        
        Args:
            base_path: Base path of the output directory.
        """
        subdirs = [
            "receptors",
            "ligands",
            "results",
            "plots",
            "3d_visuals",
        ]
        
        for subdir in subdirs:
            subdir_path = os.path.join(base_path, subdir)
            os.makedirs(subdir_path, exist_ok=True)
            logger.debug(f"Created subdirectory: {subdir_path}")
    
    @staticmethod
    def ensure_directory(directory_path: str) -> str:
        """
        Ensure that a directory exists, creating it if necessary.
        
        Args:
            directory_path: Path to the directory.
            
        Returns:
            Absolute path to the directory.
        """
        # Convert to absolute path
        abs_path = os.path.abspath(directory_path)
        
        # Create the directory if it doesn't exist
        os.makedirs(abs_path, exist_ok=True)
        
        return abs_path
    
    @staticmethod
    def get_unique_filename(directory: str, base_name: str, extension: str) -> str:
        """
        Generate a unique filename in the specified directory.
        
        Args:
            directory: Directory where the file will be created.
            base_name: Base name for the file.
            extension: File extension (without the dot).
            
        Returns:
            Unique filename.
        """
        # Make sure the extension doesn't have a leading dot
        ext = extension.lstrip(".")
        
        # Initial filename
        filename = f"{base_name}.{ext}"
        filepath = os.path.join(directory, filename)
        
        # Find a unique filename if the file already exists
        counter = 1
        while os.path.exists(filepath):
            filename = f"{base_name}_{counter}.{ext}"
            filepath = os.path.join(directory, filename)
            counter += 1
        
        return filepath