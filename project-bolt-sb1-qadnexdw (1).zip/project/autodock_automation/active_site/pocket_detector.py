"""
Module for detecting active sites and binding pockets in protein structures.
"""

from typing import List, Dict, Any, Tuple, Optional
import os
import numpy as np
from loguru import logger

from ..parser.hetero_parser import Atom


class Pocket:
    """Class representing a binding pocket in a protein structure."""
    
    def __init__(self, center: Tuple[float, float, float], size: Tuple[float, float, float]):
        """
        Initialize a Pocket object.
        
        Args:
            center: Center coordinates (x, y, z).
            size: Size dimensions (x, y, z).
        """
        self.center = center
        self.size = size
    
    def to_dict(self) -> Dict[str, float]:
        """
        Convert pocket to a dictionary.
        
        Returns:
            Dictionary representation of the pocket.
        """
        return {
            "center_x": self.center[0],
            "center_y": self.center[1],
            "center_z": self.center[2],
            "size_x": self.size[0],
            "size_y": self.size[1],
            "size_z": self.size[2],
        }
    
    @staticmethod
    def from_dict(data: Dict[str, float]) -> 'Pocket':
        """
        Create a Pocket object from a dictionary.
        
        Args:
            data: Dictionary with pocket parameters.
            
        Returns:
            Pocket object.
        """
        center = (data["center_x"], data["center_y"], data["center_z"])
        size = (data["size_x"], data["size_y"], data["size_z"])
        return Pocket(center, size)


class ActiveSiteFinder:
    """Class for detecting active sites and binding pockets in protein structures."""
    
    def __init__(self, padding: float = 4.0):
        """
        Initialize the active site finder.
        
        Args:
            padding: Padding to add around the ligand when defining a pocket (in Å).
        """
        self.padding = padding
        logger.debug(f"ActiveSiteFinder initialized with padding: {self.padding}Å")
    
    def detect_pocket(self, pdb_file: str, ligand_atoms: List[Atom]) -> Dict[str, float]:
        """
        Detect the binding pocket based on ligand atoms or using a default center.
        
        Args:
            pdb_file: Path to the PDB file.
            ligand_atoms: List of ligand atoms.
            
        Returns:
            Dictionary with pocket parameters (center_x, center_y, center_z, size_x, size_y, size_z).
        """
        logger.info(f"Detecting binding pocket in: {pdb_file}")
        
        if ligand_atoms:
            # Detect pocket based on ligand atoms
            pocket = self._detect_pocket_from_ligand(ligand_atoms)
            
        else:
            # Use protein center if no ligand atoms are provided
            from Bio.PDB import PDBParser
            parser = PDBParser(QUIET=True)
            
            try:
                structure = parser.get_structure("temp", pdb_file)
                pocket = self._detect_pocket_from_protein(structure)
            except Exception as e:
                logger.error(f"Error parsing PDB file {pdb_file}: {str(e)}")
                # Use default pocket
                pocket = Pocket(center=(0, 0, 0), size=(20, 20, 20))
        
        logger.info(
            f"Detected pocket with center ({pocket.center[0]:.2f}, {pocket.center[1]:.2f}, {pocket.center[2]:.2f}) "
            f"and size ({pocket.size[0]:.2f}, {pocket.size[1]:.2f}, {pocket.size[2]:.2f})"
        )
        
        return pocket.to_dict()
    
    def _detect_pocket_from_ligand(self, ligand_atoms: List[Atom]) -> Pocket:
        """
        Detect pocket based on ligand atoms.
        
        Args:
            ligand_atoms: List of ligand atoms.
            
        Returns:
            Pocket object.
        """
        logger.debug(f"Detecting pocket from {len(ligand_atoms)} ligand atoms")
        
        # Extract coordinates
        coords = np.array([atom.coords for atom in ligand_atoms])
        
        # Calculate center
        center = coords.mean(axis=0)
        
        # Calculate size
        min_coords = coords.min(axis=0) - self.padding
        max_coords = coords.max(axis=0) + self.padding
        size = max_coords - min_coords
        
        return Pocket(
            center=tuple(center),
            size=tuple(size),
        )
    
    def _detect_pocket_from_protein(self, structure) -> Pocket:
        """
        Detect pocket based on protein structure.
        
        Args:
            structure: BioPython structure object.
            
        Returns:
            Pocket object.
        """
        logger.debug("Detecting pocket from protein structure")
        
        # Extract coordinates of protein atoms
        coords = []
        for model in structure:
            for chain in model:
                for residue in chain:
                    # Skip heteroatoms
                    if residue.id[0] != " ":
                        continue
                    
                    for atom in residue:
                        coords.append(atom.coord)
        
        coords = np.array(coords)
        
        # Calculate center
        center = coords.mean(axis=0)
        
        # Use a fixed size
        size = (20.0, 20.0, 20.0)
        
        return Pocket(
            center=tuple(center),
            size=size,
        )
    
    def identify_pocket_residues(self, pdb_file: str, pocket: Dict[str, float], 
                                 distance_cutoff: float = 5.0) -> List[str]:
        """
        Identify residues within a certain distance of the pocket center.
        
        Args:
            pdb_file: Path to the PDB file.
            pocket: Dictionary with pocket parameters.
            distance_cutoff: Maximum distance from pocket center (in Å).
            
        Returns:
            List of residue identifiers.
        """
        logger.info(f"Identifying residues near pocket in: {pdb_file}")
        
        from Bio.PDB import PDBParser
        parser = PDBParser(QUIET=True)
        
        try:
            structure = parser.get_structure("temp", pdb_file)
            
            # Get pocket center
            pocket_obj = Pocket.from_dict(pocket)
            center = np.array(pocket_obj.center)
            
            # Identify residues within distance_cutoff of the center
            pocket_residues = []
            for model in structure:
                for chain in model:
                    for residue in chain:
                        # Skip heteroatoms
                        if residue.id[0] != " ":
                            continue
                        
                        # Calculate average position of residue atoms
                        residue_coords = []
                        for atom in residue:
                            residue_coords.append(atom.coord)
                        
                        if not residue_coords:
                            continue
                        
                        residue_center = np.mean(residue_coords, axis=0)
                        
                        # Calculate distance to pocket center
                        distance = np.linalg.norm(residue_center - center)
                        
                        if distance <= distance_cutoff:
                            res_id = f"{chain.id}:{residue.resname}:{residue.id[1]}"
                            pocket_residues.append(res_id)
            
            logger.info(f"Identified {len(pocket_residues)} residues near pocket")
            return pocket_residues
            
        except Exception as e:
            logger.error(f"Error identifying pocket residues in {pdb_file}: {str(e)}")
            return []