"""
Command-line interface for the AutoDock Automation package.
"""

import os
import sys
import click
from typing import List, Optional, Tuple
from pathlib import Path
from loguru import logger

from .config import (
    setup_logging,
    validate_docking_parameters,
    DEFAULT_EXHAUSTIVENESS,
    DEFAULT_NUM_MODES,
    DEFAULT_ENERGY_RANGE,
)
from .downloader.pdb_fetcher import PDBDownloader
from .parser.hetero_parser import HeteroAtomParser
from .active_site.pocket_detector import ActiveSiteFinder
from .prepare.receptor_prep import ReceptorPreparation
from .ligand.ligand_builder import LigandBuilder
from .docking.vina_runner import VinaRunner
from .analysis.result_parser import ResultParser
from .analysis.visualization import Visualization
from .utils.file_manager import DirectoryCleaner


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging.")
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(file_okay=False),
    default="./output",
    help="Directory to save output files.",
)
@click.pass_context
def cli(ctx, verbose: bool, output_dir: str) -> None:
    """AutoDock Automation: A tool for automating molecular docking workflows with AutoDock Vina."""
    setup_logging(verbose)
    
    # Create output directory if it doesn't exist
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Store output directory in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["output_dir"] = str(output_path)
    
    logger.info(f"Output directory set to: {output_path}")


@cli.command(name="dock")
@click.option(
    "--mode",
    type=click.Choice(["1", "2", "3", "4"]),
    required=True,
    help=(
        "Docking mode: 1) One ligand against one receptor, "
        "2) Multiple ligands against one receptor, "
        "3) One ligand against multiple receptors, "
        "4) Custom docking with specific parameters."
    ),
)
@click.option(
    "--receptor",
    help="PDB ID or file path for the receptor (for modes 1, 2, 4).",
)
@click.option(
    "--receptors",
    help="File containing list of PDB IDs or file paths for receptors (for mode 3).",
)
@click.option(
    "--ligand",
    help="SMILES string or file path for the ligand (for modes 1, 3, 4).",
)
@click.option(
    "--ligands",
    help="File containing list of SMILES strings or file paths for ligands (for mode 2).",
)
@click.option(
    "--exhaustiveness",
    type=int,
    default=DEFAULT_EXHAUSTIVENESS,
    help=f"Exhaustiveness of the global search (default: {DEFAULT_EXHAUSTIVENESS}).",
)
@click.option(
    "--num-modes",
    type=int,
    default=DEFAULT_NUM_MODES,
    help=f"Maximum number of binding modes to generate (default: {DEFAULT_NUM_MODES}).",
)
@click.option(
    "--energy-range",
    type=float,
    default=DEFAULT_ENERGY_RANGE,
    help=f"Maximum energy difference between the best and worst binding mode (default: {DEFAULT_ENERGY_RANGE}).",
)
@click.option(
    "--center-x", type=float, help="X-coordinate of the center of the search box."
)
@click.option(
    "--center-y", type=float, help="Y-coordinate of the center of the search box."
)
@click.option(
    "--center-z", type=float, help="Z-coordinate of the center of the search box."
)
@click.option(
    "--size-x", type=float, default=20.0, help="Size of the search box in the X dimension."
)
@click.option(
    "--size-y", type=float, default=20.0, help="Size of the search box in the Y dimension."
)
@click.option(
    "--size-z", type=float, default=20.0, help="Size of the search box in the Z dimension."
)
@click.option(
    "--excel-report", is_flag=True, help="Generate Excel report of docking results."
)
@click.option(
    "--plot-results", is_flag=True, help="Generate plots of docking results."
)
@click.option(
    "--render-3d", is_flag=True, help="Generate 3D renderings of docking results."
)
@click.pass_context
def dock(ctx, **kwargs) -> None:
    """Run molecular docking simulations."""
    mode = int(kwargs["mode"])
    output_dir = ctx.obj["output_dir"]
    
    logger.info(f"Running docking in mode {mode}")
    
    try:
        # Validate parameters based on mode
        validate_parameters_for_mode(mode, kwargs)
        
        # Clean output directory
        file_manager = DirectoryCleaner()
        file_manager.clean_output_dir(output_dir)
        
        # Execute docking based on mode
        if mode == 1:
            run_single_docking(kwargs, output_dir)
        elif mode == 2:
            run_multiple_ligands_docking(kwargs, output_dir)
        elif mode == 3:
            run_multiple_receptors_docking(kwargs, output_dir)
        elif mode == 4:
            run_custom_docking(kwargs, output_dir)
        
        logger.success("Docking completed successfully!")
        
    except Exception as e:
        logger.error(f"Error during docking: {str(e)}")
        sys.exit(1)


def validate_parameters_for_mode(mode: int, params: dict) -> None:
    """Validate command-line parameters based on the selected mode."""
    if mode == 1:
        if not params["receptor"] or not params["ligand"]:
            raise ValueError("Mode 1 requires --receptor and --ligand parameters.")
    elif mode == 2:
        if not params["receptor"] or not params["ligands"]:
            raise ValueError("Mode 2 requires --receptor and --ligands parameters.")
    elif mode == 3:
        if not params["receptors"] or not params["ligand"]:
            raise ValueError("Mode 3 requires --receptors and --ligand parameters.")
    elif mode == 4:
        if not params["receptor"] or not params["ligand"]:
            raise ValueError("Mode 4 requires --receptor and --ligand parameters.")
        # Validate additional docking parameters
        validate_docking_parameters(params)


def run_single_docking(params: dict, output_dir: str) -> None:
    """Run docking between a single ligand and a single receptor."""
    logger.info("Running single docking workflow")
    
    # Initialize components
    downloader = PDBDownloader()
    hetero_parser = HeteroAtomParser()
    active_site_finder = ActiveSiteFinder()
    receptor_prep = ReceptorPreparation()
    ligand_builder = LigandBuilder()
    vina_runner = VinaRunner()
    result_parser = ResultParser()
    visualization = Visualization()
    
    # Process receptor
    receptor_path = process_receptor(
        params["receptor"], 
        downloader, 
        hetero_parser, 
        receptor_prep, 
        output_dir
    )
    
    # Process ligand
    ligand_path = process_ligand(
        params["ligand"],
        ligand_builder,
        output_dir
    )
    
    # Detect active site
    pocket = detect_active_site(
        receptor_path,
        active_site_finder,
        params
    )
    
    # Run docking
    results_path = run_docking_simulation(
        receptor_path,
        ligand_path,
        pocket,
        vina_runner,
        params,
        output_dir
    )
    
    # Analyze results
    analyze_results(
        results_path,
        result_parser,
        visualization,
        params,
        output_dir
    )


def run_multiple_ligands_docking(params: dict, output_dir: str) -> None:
    """Run docking between multiple ligands and a single receptor."""
    logger.info("Running multiple ligands docking workflow")
    # Implementation follows the same pattern as run_single_docking
    # but with a loop for processing multiple ligands
    logger.info("Multiple ligands docking not yet implemented")


def run_multiple_receptors_docking(params: dict, output_dir: str) -> None:
    """Run docking between a single ligand and multiple receptors."""
    logger.info("Running multiple receptors docking workflow")
    # Implementation follows the same pattern as run_single_docking
    # but with a loop for processing multiple receptors
    logger.info("Multiple receptors docking not yet implemented")


def run_custom_docking(params: dict, output_dir: str) -> None:
    """Run custom docking with specific parameters."""
    logger.info("Running custom docking workflow")
    # Implementation similar to run_single_docking but with
    # custom parameters for the docking simulation
    logger.info("Custom docking not yet implemented")


def process_receptor(
    receptor_id: str,
    downloader: PDBDownloader,
    hetero_parser: HeteroAtomParser,
    receptor_prep: ReceptorPreparation,
    output_dir: str
) -> str:
    """Process receptor: download (if needed) and prepare for docking."""
    logger.info(f"Processing receptor: {receptor_id}")
    
    # Check if receptor is a file path or PDB ID
    if os.path.isfile(receptor_id):
        receptor_path = receptor_id
    else:
        # Download PDB file
        receptor_path = downloader.fetch_by_uniprot(receptor_id)[0]
    
    # Identify heteroatoms
    heteroatoms = hetero_parser.identify_heteroatoms(receptor_path)
    
    # Prepare receptor
    prepared_path = os.path.join(output_dir, "receptor_prepared.pdb")
    receptor_prep.remove_water(receptor_path, prepared_path)
    receptor_prep.remove_hetero(prepared_path, prepared_path, [])
    receptor_prep.add_polar_hydrogens(prepared_path, prepared_path)
    receptor_prep.fix_missing_atoms(prepared_path, prepared_path)
    receptor_prep.assign_charges(prepared_path, prepared_path)
    
    # Convert to PDBQT
    pdbqt_path = os.path.join(output_dir, "receptor.pdbqt")
    receptor_prep.to_pdbqt(prepared_path, pdbqt_path)
    
    return pdbqt_path


def process_ligand(
    ligand_input: str,
    ligand_builder: LigandBuilder,
    output_dir: str
) -> str:
    """Process ligand: convert from SMILES or file, optimize, and prepare for docking."""
    logger.info(f"Processing ligand: {ligand_input}")
    
    # Check if ligand is a file path or SMILES string
    if os.path.isfile(ligand_input):
        # Parse ligand file
        mol = ligand_builder.file_to_3d(ligand_input)
    else:
        # Convert SMILES to 3D structure
        mol = ligand_builder.smiles_to_3d(ligand_input)
    
    # Optimize structure
    mol = ligand_builder.optimize_structure(mol)
    
    # Identify torsions
    torsions = ligand_builder.identify_torsions(mol)
    
    # Convert to PDBQT
    pdbqt_path = os.path.join(output_dir, "ligand.pdbqt")
    ligand_builder.to_pdbqt(mol, pdbqt_path)
    
    return pdbqt_path


def detect_active_site(
    receptor_path: str,
    active_site_finder: ActiveSiteFinder,
    params: dict
) -> dict:
    """Detect active site or use provided coordinates."""
    logger.info("Detecting active site")
    
    # Check if coordinates are provided
    if params.get("center_x") and params.get("center_y") and params.get("center_z"):
        pocket = {
            "center_x": params["center_x"],
            "center_y": params["center_y"],
            "center_z": params["center_z"],
            "size_x": params["size_x"],
            "size_y": params["size_y"],
            "size_z": params["size_z"],
        }
        logger.info(f"Using provided search box: {pocket}")
    else:
        # Detect pocket automatically
        pocket = active_site_finder.detect_pocket(receptor_path, [])
        logger.info(f"Detected search box: {pocket}")
    
    return pocket


def run_docking_simulation(
    receptor_path: str,
    ligand_path: str,
    pocket: dict,
    vina_runner: VinaRunner,
    params: dict,
    output_dir: str
) -> str:
    """Run AutoDock Vina docking simulation."""
    logger.info("Running docking simulation")
    
    # Generate Vina configuration file
    config_path = os.path.join(output_dir, "vina_config.txt")
    vina_runner.generate_config(
        pocket,
        config_path,
        exhaustiveness=params["exhaustiveness"],
        num_modes=params["num_modes"],
        energy_range=params["energy_range"],
    )
    
    # Run docking
    log_path = os.path.join(output_dir, "vina_log.txt")
    out_path = os.path.join(output_dir, "docked_ligand.pdbqt")
    vina_runner.run_docking(receptor_path, ligand_path, config_path, out_path, log_path)
    
    return out_path


def analyze_results(
    results_path: str,
    result_parser: ResultParser,
    visualization: Visualization,
    params: dict,
    output_dir: str
) -> None:
    """Analyze docking results and generate reports."""
    logger.info("Analyzing docking results")
    
    # Parse results
    results_df = result_parser.parse(results_path)
    
    # Generate Excel report if requested
    if params.get("excel_report"):
        excel_path = os.path.join(output_dir, "docking_results.xlsx")
        visualization.save_to_excel(results_df, excel_path)
        logger.info(f"Excel report saved to: {excel_path}")
    
    # Generate plots if requested
    if params.get("plot_results"):
        plot_path = os.path.join(output_dir, "binding_energies.png")
        visualization.plot_binding_energies(results_df, plot_path)
        logger.info(f"Energy plot saved to: {plot_path}")
    
    # Generate 3D visualizations if requested
    if params.get("render_3d"):
        visual_dir = os.path.join(output_dir, "3d_visuals")
        os.makedirs(visual_dir, exist_ok=True)
        best_poses = result_parser.extract_best_poses(results_path, 3)
        visualization.generate_3d_images(best_poses, visual_dir)
        logger.info(f"3D visualizations saved to: {visual_dir}")


def main():
    """Entry point for the CLI."""
    cli(obj={})


if __name__ == "__main__":
    main()