from setuptools import setup, find_packages

setup(
    name="autodock-automation",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "biopython>=1.79",
        "numpy>=1.20.0",
        "pandas>=1.3.0",
        "matplotlib>=3.4.0",
        "rdkit>=2021.03.1",
        "openpyxl>=3.0.7",
        "py3Dmol>=1.8.0",
        "click>=8.0.0",
        "loguru>=0.5.3",
        "tqdm>=4.62.0",
    ],
    entry_points={
        "console_scripts": [
            "autodock-vina=autodock_automation.cli:main",
        ],
    },
    author="Your Name",
    author_email="your.email@example.com",
    description="A comprehensive Python package for automating molecular docking workflows with AutoDock Vina",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/autodock-automation",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Bio-Informatics",
        "Topic :: Scientific/Engineering :: Chemistry",
    ],
    python_requires=">=3.9",
    include_package_data=True,
    package_data={
        "autodock_automation": ["templates/*.tpl"],
    },
)