# AutoDock Automation

A comprehensive Python package for automating molecular docking workflows with AutoDock Vina.

## Features

- Complete automation of molecular docking workflows
- Support for multiple docking scenarios:
  - One ligand against multiple receptors
  - Multiple ligands against one receptor
  - Multiple ligands against multiple receptors
  - Custom docking based on specific parameters
- Automated downloading of receptor structures from PDB
- Preparation of receptors and ligands for docking
- Execution of docking simulations using AutoDock Vina
- Analysis and visualization of docking results
- Generation of reports in various formats (Excel, CSV, etc.)

## Installation

```bash
pip install autodock-automation
```

## Requirements

- Python ≥3.9
- AutoDock Vina
- Open Babel or RDKit
- Additional dependencies listed in requirements.txt

## Quick Start

```bash
# Dock a single ligand against a receptor
autodock-vina --mode 1 --receptor 1ABC --ligand "CC(=O)OC1=CC=CC=C1C(=O)O"

# Dock multiple ligands against a receptor
autodock-vina --mode 2 --receptor 1ABC --ligands ligands.smi

# Dock a ligand against multiple receptors
autodock-vina --mode 3 --receptors receptors.txt --ligand "CC(=O)OC1=CC=CC=C1C(=O)O"

# Custom docking with specific parameters
autodock-vina --mode 4 --receptor 1ABC --ligand "CC(=O)OC1=CC=CC=C1C(=O)O" --exhaustiveness 8 --num_modes 10
```

## Documentation

For detailed documentation, see the [docs](docs/) directory.

## License

MIT License